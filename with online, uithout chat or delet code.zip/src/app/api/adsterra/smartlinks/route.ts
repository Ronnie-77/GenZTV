import { NextRequest, NextResponse } from 'next/server'
import { requireAdminAuth } from '@/lib/auth'
import { fetchAdsterra, clearAdsterraCache } from '@/lib/adsterra'

/**
 * GET /api/adsterra/smartlinks
 *
 * Returns the list of Adsterra Smartlink / Direct Link ad units for the
 * configured publisher account.
 *
 * Server-side only — token never exposed.
 */
export async function GET(req: NextRequest) {
  return requireAdminAuth(req, async () => {
    try {
      if (new URL(req.url).searchParams.get('refresh') === '1') {
        clearAdsterraCache()
      }
      const result = await fetchAdsterra<unknown>('smartlinks', {}, 10 * 60 * 1000)
      if (!result.ok) {
        return NextResponse.json(
          { error: result.error, status: result.status },
          { status: 502 },
        )
      }
      return NextResponse.json({
        data: result.data,
        fetchedAt: new Date().toISOString(),
      })
    } catch (error) {
      console.error('[Adsterra] Smartlinks error:', error)
      const message = error instanceof Error ? error.message : 'Failed to fetch smartlinks'
      return NextResponse.json({ error: message }, { status: 500 })
    }
  })
}
