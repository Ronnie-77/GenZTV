import { NextRequest, NextResponse } from 'next/server'
import { requireAdminAuth } from '@/lib/auth'
import { fetchAdsterra, clearAdsterraCache } from '@/lib/adsterra'

/**
 * GET /api/adsterra/placements
 *
 * Returns the list of all Adsterra ad placements (id, domain_id, title)
 * for the configured publisher account. Useful for the dashboard to label
 * which ad unit each stat row refers to.
 *
 * Server-side only — token never exposed.
 */
export async function GET(req: NextRequest) {
  return requireAdminAuth(req, async () => {
    try {
      if (new URL(req.url).searchParams.get('refresh') === '1') {
        clearAdsterraCache()
      }
      const result = await fetchAdsterra<unknown>('placements.json', {}, 10 * 60 * 1000)
      if (!result.ok) {
        return NextResponse.json(
          { error: result.error, status: result.status, kind: result.kind },
          { status: 502 },
        )
      }
      return NextResponse.json({
        data: result.data,
        fetchedAt: new Date().toISOString(),
      })
    } catch (error) {
      console.error('[Adsterra] Placements error:', error)
      const message = error instanceof Error ? error.message : 'Failed to fetch placements'
      return NextResponse.json({ error: message }, { status: 500 })
    }
  })
}
