import { NextRequest, NextResponse } from 'next/server'
import { requireAdminAuth } from '@/lib/auth'
import { fetchAdsterra, clearAdsterraCache } from '@/lib/adsterra'

/**
 * GET /api/adsterra/stats?start=YYYY-MM-DD&end=YYYY-MM-DD&group_by=date
 *
 * Returns daily Adsterra statistics (revenue, impressions, clicks, CPM, CTR)
 * for the given date range. Defaults to last 14 days.
 *
 * Server-side only — Adsterra API token is read from AppSetting and never
 * exposed to the browser.
 *
 * Frontend sends:      start, end, group_by (single string, optional)
 * Adsterra expects:    start_date, finish_date, group_by[] (array)
 * We translate here.
 */
export async function GET(req: NextRequest) {
  return requireAdminAuth(req, async () => {
    try {
      const url = new URL(req.url)
      const today = new Date()
      const twoWeeksAgo = new Date()
      twoWeeksAgo.setDate(today.getDate() - 13)

      const fmt = (d: Date) => d.toISOString().slice(0, 10)
      const start = url.searchParams.get('start') || fmt(twoWeeksAgo)
      const end = url.searchParams.get('end') || fmt(today)
      const groupBy = url.searchParams.get('group_by') // date | domain | placement | country

      // If ?refresh=1, bust the cache so the next fetch hits Adsterra fresh.
      if (url.searchParams.get('refresh') === '1') {
        clearAdsterraCache()
      }

      // Translate to Adsterra's API params.
      const query: Record<string, string | string[]> = {
        start_date: start,
        finish_date: end,
      }
      if (groupBy) query.group_by = [groupBy]

      const result = await fetchAdsterra<unknown>('stats.json', query, 5 * 60 * 1000)

      if (!result.ok) {
        return NextResponse.json(
          { error: result.error, status: result.status, kind: result.kind },
          { status: 502 },
        )
      }

      return NextResponse.json({
        range: { start, end },
        data: result.data,
        cached: false,
        fetchedAt: new Date().toISOString(),
      })
    } catch (error) {
      console.error('[Adsterra] Stats error:', error)
      const message = error instanceof Error ? error.message : 'Failed to fetch Adsterra stats'
      return NextResponse.json({ error: message }, { status: 500 })
    }
  })
}
