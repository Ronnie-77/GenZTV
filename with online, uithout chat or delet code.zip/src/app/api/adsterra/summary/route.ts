import { NextRequest, NextResponse } from 'next/server'
import { requireAdminAuth } from '@/lib/auth'
import { fetchAdsterra, clearAdsterraCache, hasAdsterraToken } from '@/lib/adsterra'

/**
 * GET /api/adsterra/summary
 *
 * Combined Adsterra dashboard payload — fetches stats + domains + placements
 * in parallel so the frontend can render the entire Adsterra panel with one
 * request.
 *
 * Response shape:
 * {
 *   configured: boolean,
 *   stats:     { ok, data?, error?, kind?, range: {start,end} },
 *   domains:   { ok, data?, error?, kind? },
 *   placements:{ ok, data?, error?, kind? },
 *   fetchedAt: string
 * }
 *
 * Note: Adsterra's Publisher API does NOT expose a balance endpoint.
 * Balance is only visible in the Adsterra web dashboard at
 * https://adsterra.com/dashboard — we surface that as a link in the UI.
 *
 * Server-side only.
 */
export async function GET(req: NextRequest) {
  return requireAdminAuth(req, async () => {
    try {
      if (new URL(req.url).searchParams.get('refresh') === '1') {
        clearAdsterraCache()
      }

      const configured = await hasAdsterraToken()
      if (!configured) {
        return NextResponse.json({
          configured: false,
          stats: { ok: false, error: 'Not configured' },
          domains: { ok: false, error: 'Not configured' },
          placements: { ok: false, error: 'Not configured' },
          fetchedAt: new Date().toISOString(),
        })
      }

      const today = new Date()
      const thirtyDaysAgo = new Date()
      thirtyDaysAgo.setDate(today.getDate() - 29)
      const fmt = (d: Date) => d.toISOString().slice(0, 10)

      // Fire all three requests in parallel. We use Promise.allSettled-style
      // via the per-call result objects so one failure doesn't take down the
      // whole panel.
      const [statsResult, domainsResult, placementsResult] = await Promise.all([
        fetchAdsterra<unknown>(
          'stats.json',
          {
            start_date: fmt(thirtyDaysAgo),
            finish_date: fmt(today),
            group_by: ['date'],
          },
          5 * 60 * 1000,
        ),
        fetchAdsterra<unknown>('domains.json', {}, 10 * 60 * 1000),
        fetchAdsterra<unknown>('placements.json', {}, 10 * 60 * 1000),
      ])

      return NextResponse.json({
        configured: true,
        stats: statsResult.ok
          ? { ok: true, data: statsResult.data, range: { start: fmt(thirtyDaysAgo), end: fmt(today) } }
          : { ok: false, error: statsResult.error, kind: statsResult.kind },
        domains: domainsResult.ok
          ? { ok: true, data: domainsResult.data }
          : { ok: false, error: domainsResult.error, kind: domainsResult.kind },
        placements: placementsResult.ok
          ? { ok: true, data: placementsResult.data }
          : { ok: false, error: placementsResult.error, kind: placementsResult.kind },
        fetchedAt: new Date().toISOString(),
      })
    } catch (error) {
      console.error('[Adsterra] Summary error:', error)
      const message = error instanceof Error ? error.message : 'Failed to fetch Adsterra summary'
      return NextResponse.json({ error: message }, { status: 500 })
    }
  })
}
