import { NextRequest, NextResponse } from 'next/server'
import { requireAdminAuth } from '@/lib/auth'
import { fetchAdsterra, clearAdsterraCache } from '@/lib/adsterra'

/**
 * GET /api/adsterra/balance
 *
 * Returns the current Adsterra account balance + pending payouts.
 *
 * Server-side only — token never exposed.
 */
export async function GET(req: NextRequest) {
  return requireAdminAuth(req, async () => {
    try {
      if (new URL(req.url).searchParams.get('refresh') === '1') {
        clearAdsterraCache()
      }
      const result = await fetchAdsterra<unknown>('balance', {}, 5 * 60 * 1000)
      if (!result.ok) {
        return NextResponse.json(
          { error: result.error, status: result.status },
          { status: 502 },
        )
      }
      return NextResponse.json({
        data: result.data,
        fetchedAt: new Date().toISOString(),
      })
    } catch (error) {
      console.error('[Adsterra] Balance error:', error)
      const message = error instanceof Error ? error.message : 'Failed to fetch balance'
      return NextResponse.json({ error: message }, { status: 500 })
    }
  })
}
