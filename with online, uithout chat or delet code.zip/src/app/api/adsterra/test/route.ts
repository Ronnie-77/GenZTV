import { NextRequest, NextResponse } from 'next/server'
import { requireAdminAuth } from '@/lib/auth'
import { db } from '@/lib/db'

/**
 * POST /api/adsterra/test
 *
 * Tests an Adsterra Publisher API token by making a single lightweight request
 * to the /publisher/stats.json endpoint with a 1-day range.
 *
 * Body (optional):
 *   { "token": "<32-char hex string>" }
 *
 * If `token` is omitted, the currently-saved token from AppSetting is used.
 * This lets the admin test a token BEFORE saving it (paste → test → save).
 *
 * Response shape:
 *   { valid: boolean, message: string, status?: number, sample?: unknown }
 *
 * Server-side only — never exposes the token to the browser.
 */
export async function POST(req: NextRequest) {
  return requireAdminAuth(req, async () => {
    try {
      // Determine which token to test: body-provided, or saved in DB.
      let token = ''
      try {
        const body = await req.json()
        if (typeof body?.token === 'string') {
          token = body.token.trim()
        }
      } catch {
        /* body may be empty — fall through to saved token */
      }

      if (!token) {
        const settings = await db.appSetting.findUnique({ where: { id: 'app' } })
        token = (settings?.adsterraApiToken || '').trim()
      }

      if (!token) {
        return NextResponse.json({
          valid: false,
          message: 'No token provided. Paste your Adsterra API token first.',
        })
      }

      // Note: Adsterra tokens are normally 32-char hex strings, but we accept
      // any non-empty value and let Adsterra's server give the real verdict.

      // Make a 1-day stats request to verify the token.
      const today = new Date()
      const yesterday = new Date()
      yesterday.setDate(today.getDate() - 1)
      const fmt = (d: Date) => d.toISOString().slice(0, 10)

      const url = new URL('https://api3.adsterratools.com/publisher/stats.json')
      url.searchParams.set('start_date', fmt(yesterday))
      url.searchParams.set('finish_date', fmt(today))
      url.searchParams.append('group_by', 'date')

      const controller = new AbortController()
      const timeout = setTimeout(() => controller.abort(), 15_000)

      let status = 0
      let sample: unknown = null
      let serverMsg = ''

      try {
        const res = await fetch(url.toString(), {
          signal: controller.signal,
          headers: {
            Accept: 'application/json',
            'X-API-Key': token,
            'User-Agent': 'GenZTV-Admin/1.0 (Adsterra token test)',
          },
        })
        clearTimeout(timeout)
        status = res.status

        const text = await res.text()
        // Try to parse JSON (Adsterra returns JSON for both success AND error)
        try {
          const j = JSON.parse(text)
          sample = Array.isArray(j) ? j.slice(0, 2) : j
          if (j?.message) serverMsg = j.message
          if (j?.error) serverMsg = j.error
        } catch {
          /* not JSON — probably HTML from a misrouted request */
          serverMsg = text.slice(0, 200)
        }

        if (res.status === 200) {
          return NextResponse.json({
            valid: true,
            status: 200,
            message: 'Token is valid. Adsterra accepted the request and returned stats data.',
            sample,
          })
        }

        if (res.status === 401 || res.status === 403) {
          return NextResponse.json({
            valid: false,
            status: res.status,
            message:
              `Adsterra rejected the token (HTTP ${res.status}).` +
              (serverMsg ? ` Server said: "${serverMsg}".` : '') +
              ` Make sure this is your Publisher API token from Adsterra → Account Settings → API tab (NOT the ad code snippet).`,
          })
        }

        return NextResponse.json({
          valid: false,
          status: res.status,
          message: `Adsterra returned HTTP ${res.status}.${serverMsg ? ` ${serverMsg}` : ''}`,
        })
      } catch (err) {
        clearTimeout(timeout)
        const msg = err instanceof Error ? err.message : 'Network error'
        return NextResponse.json({
          valid: false,
          message: `Could not reach Adsterra's API: ${msg}. Check your internet connection and try again.`,
        })
      }
    } catch (error) {
      console.error('[Adsterra test] Error:', error)
      const message = error instanceof Error ? error.message : 'Failed to test token'
      return NextResponse.json({ valid: false, message }, { status: 500 })
    }
  })
}
