import { db } from '@/lib/db'

/**
 * Shared helpers for the Adsterra Publisher API integration.
 *
 * All Adsterra API calls are made SERVER-SIDE because the API token is a
 * secret credential. It is never exposed to the browser.
 *
 * The token is stored in the AppSetting table (field `adsterraApiToken`)
 * and is configurable from the admin Settings page.
 *
 * ─── Adsterra Publisher API (current, May 2024+) ─────────────────────────
 *   Base URL : https://api3.adsterratools.com/publisher
 *   Auth     : HTTP header  `X-API-Key: <token>`
 *   Accept   : application/json
 *
 *   Endpoints used here:
 *     - GET /stats.json       Daily revenue / impressions / clicks / CPM / CTR
 *                              Query: start_date, finish_date, group_by[],
 *                                     domain, placement, country
 *     - GET /domains.json     List of publisher websites (id, title)
 *     - GET /placements.json  List of all ad placements (id, domain_id, title)
 *
 *   Stats response (group_by[]=date):
 *     [{ date, impressions, clicks, ctr, cpm, revenue }, ...]
 *
 *   Error responses are JSON, e.g.:
 *     HTTP 403  { "message": "Invalid token provided" }
 *
 *   Documentation: https://adsterra.com/blog/how-to-use-adsterra-publishers-api/
 *
 * Note: The Adsterra Publisher API does NOT expose a balance endpoint.
 * Balance / payouts are only visible in the Adsterra web dashboard.
 */

export const ADSTERRA_API_BASE = 'https://api3.adsterratools.com/publisher'

/** Read the saved Adsterra API token from the DB. Returns '' if not set. */
export async function getAdsterraToken(): Promise<string> {
  const settings = await db.appSetting.findUnique({ where: { id: 'app' } })
  return (settings?.adsterraApiToken || '').trim()
}

/** True if an Adsterra API token has been configured. */
export async function hasAdsterraToken(): Promise<boolean> {
  return (await getAdsterraToken()).length > 0
}

/**
 * In-memory cache for Adsterra API responses. Adsterra stats do not change
 * real-time (they update roughly hourly), so we cache for a few minutes to
 * avoid hitting rate limits and keep the dashboard snappy.
 *
 * Key = endpoint URL (with query string). Value = { data, expiresAt }.
 */
interface CacheEntry<T> {
  data: T
  expiresAt: number
}
const cache = new Map<string, CacheEntry<unknown>>()

interface AdsterraError {
  ok: false
  error: string
  status?: number
  /** Hint token-invalid / token-missing so the UI can show a targeted message. */
  kind?: 'token-invalid' | 'token-missing' | 'network' | 'unknown'
}
interface AdsterraOk<T> {
  ok: true
  data: T
}
export type AdsterraResult<T = unknown> = AdsterraOk<T> | AdsterraError

/**
 * Fetch a URL from Adsterra's API with caching + timeout + retry.
 *
 * @param path     Path under /publisher/ (e.g. "stats.json", "domains.json").
 * @param query    Extra query params (token is sent via X-API-Key header, NOT in URL).
 * @param ttlMs    Cache TTL in milliseconds (default 5 min).
 */
export async function fetchAdsterra<T = unknown>(
  path: string,
  query: Record<string, string | string[]> = {},
  ttlMs: number = 5 * 60 * 1000,
): Promise<AdsterraResult<T>> {
  const token = await getAdsterraToken()
  if (!token) {
    return {
      ok: false,
      kind: 'token-missing',
      error: 'Adsterra API token is not configured. Add it in Admin → Settings → Adsterra Revenue API.',
    }
  }

  // Build URL: /publisher/<path>?<query>
  const url = new URL(`${ADSTERRA_API_BASE}/${path.replace(/^\//, '')}`)
  for (const [k, v] of Object.entries(query)) {
    if (v === undefined || v === null || v === '') continue
    if (Array.isArray(v)) {
      for (const item of v) {
        if (item) url.searchParams.append(k, item)
      }
    } else {
      url.searchParams.set(k, v)
    }
  }

  const cacheKey = url.toString()
  const cached = cache.get(cacheKey) as CacheEntry<T> | undefined
  const now = Date.now()
  if (cached && cached.expiresAt > now) {
    return { ok: true, data: cached.data }
  }

  // Retry with exponential backoff (Adsterra can be flaky / Cloudflare rate-limit).
  let lastError = ''
  let lastStatus: number | undefined
  let lastKind: AdsterraError['kind'] = 'unknown'
  for (let attempt = 0; attempt < 2; attempt++) {
    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), 15_000)
    try {
      const res = await fetch(url.toString(), {
        signal: controller.signal,
        headers: {
          Accept: 'application/json',
          'X-API-Key': token,
          'User-Agent': 'GenZTV-Admin/1.0 (Adsterra Publisher API client)',
        },
      })
      clearTimeout(timeout)
      lastStatus = res.status

      // Always read the body as text first — Adsterra returns JSON for both
      // success AND error responses, but we want to handle unexpected HTML too.
      const text = await res.text()

      if (res.status === 401 || res.status === 403) {
        // Token invalid / revoked — don't retry, clear cache.
        cache.delete(cacheKey)
        // Try to parse Adsterra's JSON error message.
        let serverMsg = ''
        try {
          const j = JSON.parse(text)
          serverMsg = j.message || j.error || ''
        } catch {
          /* not JSON */
        }
        return {
          ok: false,
          kind: 'token-invalid',
          status: res.status,
          error:
            `Adsterra rejected the API token (HTTP ${res.status}).` +
            (serverMsg ? ` Server said: "${serverMsg}".` : '') +
            ` Please verify the token in Admin → Settings → Adsterra Revenue API matches the one in your Adsterra dashboard → Account Settings → API.`,
        }
      }

      if (!res.ok) {
        let serverMsg = ''
        try {
          const j = JSON.parse(text)
          serverMsg = j.message || j.error || ''
        } catch {
          /* not JSON */
        }
        lastError =
          `Adsterra API returned HTTP ${res.status}.` +
          (serverMsg ? ` ${serverMsg}` : text ? ` ${text.slice(0, 200)}` : '')
        if (attempt < 1) {
          await new Promise((r) => setTimeout(r, 600 * (attempt + 1)))
          continue
        }
        cache.delete(cacheKey)
        return { ok: false, kind: 'unknown', error: lastError, status: res.status }
      }

      // Parse JSON. Adsterra returns JSON for success responses.
      let data: T
      try {
        data = JSON.parse(text) as T
      } catch {
        // Got a 200 but body is HTML (e.g. Cloudflare interstitial or a redirect
        // to the marketing site). This shouldn't happen with api3.adsterratools.com
        // but we handle it defensively.
        cache.delete(cacheKey)
        return {
          ok: false,
          kind: 'unknown',
          error:
            'Adsterra returned a non-JSON response. This is usually temporary (Cloudflare interstitial). Try again in a minute.' +
            (text ? ` First 200 chars: ${text.slice(0, 200)}` : ''),
          status: res.status,
        }
      }

      cache.set(cacheKey, { data, expiresAt: now + ttlMs })
      return { ok: true, data }
    } catch (err) {
      clearTimeout(timeout)
      lastKind = 'network'
      lastError = err instanceof Error ? err.message : 'Unknown fetch error'
      if (attempt < 1) {
        await new Promise((r) => setTimeout(r, 600 * (attempt + 1)))
        continue
      }
      cache.delete(cacheKey)
      return { ok: false, kind: lastKind, error: lastError }
    }
  }

  cache.delete(cacheKey)
  return { ok: false, kind: lastKind, error: lastError || 'Unknown error', status: lastStatus }
}

/** Clear the in-memory cache. Call when the token changes or for manual refresh. */
export function clearAdsterraCache(): void {
  cache.clear()
}
