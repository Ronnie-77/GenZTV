import webpush from 'web-push'
import { db } from '@/lib/db'

// Configure web-push with VAPID details
if (process.env.VAPID_PRIVATE_KEY && process.env.VAPID_SUBJECT) {
  webpush.setVapidDetails(
    process.env.VAPID_SUBJECT,
    process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY!,
    process.env.VAPID_PRIVATE_KEY
  )
}

export interface PushSubscriptionData {
  endpoint: string
  keys: {
    p256dh: string
    auth: string
  }
}

/**
 * Send a push notification to ALL subscribed users
 */
export async function sendPushToAll(payload: {
  title: string
  body: string
  icon?: string
  image?: string
  url?: string
  tag?: string
}) {
  const subscriptions = await db.pushSubscription.findMany()

  if (subscriptions.length === 0) {
    return { sent: 0, failed: 0 }
  }

  const notificationPayload = JSON.stringify({
    title: payload.title,
    body: payload.body,
    icon: payload.icon || '/logo.svg',
    // `image` is the larger banner shown below the title/body on Android
    // and desktop Chrome. If the caller provides an icon (e.g. a team logo),
    // we also surface it as the banner image so the branding is prominent.
    image: payload.image || payload.icon || '/logo.svg',
    url: payload.url || '/',
    tag: payload.tag || 'genztv-notification',
  })

  let sent = 0
  let failed = 0
  const invalidSubscriptions: string[] = []

  // Send to each subscription
  const results = await Promise.allSettled(
    subscriptions.map(async (sub) => {
      try {
        const pushSubscription: PushSubscriptionData = {
          endpoint: sub.endpoint,
          keys: {
            p256dh: sub.p256dh,
            auth: sub.auth,
          },
        }
        await webpush.sendNotification(pushSubscription, notificationPayload)
        sent++
      } catch (error: unknown) {
        failed++
        // If subscription is invalid (410 Gone or 404), mark for deletion
        if (
          error instanceof Error &&
          'statusCode' in error &&
          ((error as { statusCode: number }).statusCode === 410 ||
           (error as { statusCode: number }).statusCode === 404)
        ) {
          invalidSubscriptions.push(sub.id)
        }
        console.error('Push send failed for', sub.endpoint, error)
      }
    })
  )

  // Clean up invalid subscriptions
  if (invalidSubscriptions.length > 0) {
    await db.pushSubscription.deleteMany({
      where: { id: { in: invalidSubscriptions } },
    })
  }

  return { sent, failed, removed: invalidSubscriptions.length }
}

/**
 * Send a push notification about a new match
 *
 * NOTE: This is kept for backwards compatibility but is NO LONGER called
 * automatically when a match is created. Per the new product decision,
 * users should receive a notification when a match goes LIVE (see
 * sendMatchLiveNotification), not when it is merely scheduled.
 */
export async function sendNewMatchNotification(match: {
  title: string
  sport: string
  teamA: string
  teamB: string
  league?: string
  id: string
}) {
  const sportEmoji = match.sport === 'cricket' ? '🏏' : match.sport === 'football' ? '⚽' : '🏆'
  const leagueText = match.league ? ` | ${match.league}` : ''

  return sendPushToAll({
    title: `${sportEmoji} New Match Alert!`,
    body: `${match.teamA} vs ${match.teamB}${leagueText}`,
    url: `/#/watch`,
    tag: `match-${match.id}`,
  })
}

/**
 * Send a "match is LIVE now" push notification.
 *
 * Per the new product decision:
 *   - Users get notified when a match goes LIVE (not when it's scheduled).
 *   - The notification body shows both team names.
 *   - The notification icon shows the home team's logo (teamALogo) so users
 *     can recognize the match at a glance. We fall back to teamB's logo,
 *     then to the default app logo if neither is set.
 *   - Clicking the notification opens the match's watch page directly.
 *
 * @param match  The match object (must include teamA/B + logos + id).
 * @returns      { sent, failed, removed } or { sent: 0, failed: 0 } if no subscribers.
 */
export async function sendMatchLiveNotification(match: {
  id: string
  title: string
  sport: string
  teamA: string
  teamALogo?: string
  teamB: string
  teamBLogo?: string
  league?: string
}) {
  const sportEmoji = match.sport === 'cricket' ? '🏏' : match.sport === 'football' ? '⚽' : '🏆'
  const leagueText = match.league ? ` • ${match.league}` : ''

  // Prefer teamA's logo for the notification icon, fall back to teamB, then app logo.
  const icon = match.teamALogo || match.teamBLogo || '/logo.svg'

  return sendPushToAll({
    title: `${sportEmoji} LIVE NOW: ${match.teamA} vs ${match.teamB}`,
    body: `The match has started!${leagueText} Tap to watch live.`,
    icon,
    url: `/#/watch/${match.id}`,
    tag: `match-live-${match.id}`,
  })
}

export { webpush }
