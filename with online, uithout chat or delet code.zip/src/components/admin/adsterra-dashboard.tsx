'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  BarChart,
  Bar,
  Cell,
} from 'recharts'
import {
  DollarSign,
  MousePointerClick,
  Eye as EyeIcon,
  TrendingUp,
  RefreshCw,
  AlertCircle,
  Loader2,
  Percent,
  KeyRound,
  ExternalLink,
  Globe,
  LayoutGrid,
  Wallet,
} from 'lucide-react'
import { Button } from '@/components/ui/button'

/**
 * AdsterraDashboard — revenue & performance panel shown on the admin Analytics page.
 *
 * Fetches /api/adsterra/summary (admin-only server route) which proxies the
 * Adsterra Publisher API (api3.adsterratools.com) using the saved token.
 * The token itself never leaves the server.
 *
 * Defensive parsing: Adsterra's exact response shape varies between accounts
 * and can change without notice, so we coerce / fallback at every step.
 */

// ── Types ──────────────────────────────────────────────────────────────────

interface EndpointResult<T = unknown> {
  ok: boolean
  data?: T
  error?: string
  kind?: 'token-invalid' | 'token-missing' | 'network' | 'unknown'
}

interface AdsterraSummary {
  configured: boolean
  stats?: EndpointResult & { range?: { start: string; end: string } }
  domains?: EndpointResult
  placements?: EndpointResult
  fetchedAt?: string
  error?: string
}

interface DailyStat {
  date?: string
  revenue?: number
  impressions?: number
  clicks?: number
  ctr?: number
  cpm?: number
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [k: string]: any
}

interface ParsedStats {
  totalRevenue: number
  totalImpressions: number
  totalClicks: number
  avgCpm: number
  avgCtr: number
  daily: { date: string; revenue: number; impressions: number; clicks: number; cpm: number }[]
}

interface PlacementInfo {
  count: number
  items: { id: string | number; title: string; domainId?: string | number }[]
}

interface DomainInfo {
  count: number
  items: { id: string | number; title: string }[]
}

// ── Helpers ────────────────────────────────────────────────────────────────

const fmtMoney = (n: number) => {
  if (!isFinite(n)) return '$0.00'
  return `$${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
}

const fmtNum = (n: number) => {
  if (!isFinite(n)) return '0'
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(2).replace(/\.00$/, '') + 'M'
  if (n >= 1_000) return (n / 1_000).toFixed(1).replace(/\.0$/, '') + 'K'
  return n.toLocaleString()
}

const fmtDate = (d: string) => {
  try {
    const date = new Date(d)
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  } catch {
    return d
  }
}

// Coerce any value to a non-negative number.
const toNum = (v: unknown): number => {
  if (typeof v === 'number') return isNaN(v) ? 0 : Math.max(0, v)
  if (typeof v === 'string') {
    const n = parseFloat(v.replace(/[^0-9.\-]/g, ''))
    return isNaN(n) ? 0 : Math.max(0, n)
  }
  return 0
}

/**
 * Extract daily stats from Adsterra's stats.json response.
 *
 * Adsterra returns (with group_by[]=date):
 *   [ { date, impressions, clicks, ctr, cpm, revenue }, ... ]
 *
 * But we also defensively handle:
 *   { stats: [...] } / { data: [...] } / { "<date>": {...} } / single aggregate
 */
function parseStats(data: unknown): ParsedStats {
  const empty: ParsedStats = {
    totalRevenue: 0,
    totalImpressions: 0,
    totalClicks: 0,
    avgCpm: 0,
    avgCtr: 0,
    daily: [],
  }
  if (!data || typeof data !== 'object') return empty

  let dailyArr: DailyStat[] | null = null
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const obj = data as any
  if (Array.isArray(obj)) {
    dailyArr = obj
  } else if (Array.isArray(obj.stats)) {
    dailyArr = obj.stats
  } else if (Array.isArray(obj.data)) {
    dailyArr = obj.data
  } else if (Array.isArray(obj.items)) {
    dailyArr = obj.items
  } else if (Array.isArray(obj.result)) {
    dailyArr = obj.result
  } else if (Array.isArray(obj.results)) {
    dailyArr = obj.results
  } else {
    // Date-keyed object: { "2026-06-01": { revenue: 1.23, ... } }
    const dateKeys = Object.keys(obj).filter((k) => /^\d{4}-\d{2}-\d{2}/.test(k))
    if (dateKeys.length > 0) {
      dailyArr = dateKeys.map((k) => ({ date: k, ...obj[k] }))
    }
  }

  if (!dailyArr || dailyArr.length === 0) {
    // Maybe data IS already an aggregate { revenue, impressions, clicks }
    return {
      ...empty,
      totalRevenue: toNum(obj.revenue ?? obj.total_revenue),
      totalImpressions: toNum(obj.impressions ?? obj.total_impressions),
      totalClicks: toNum(obj.clicks ?? obj.total_clicks),
      avgCpm: toNum(obj.cpm ?? obj.avg_cpm ?? obj.eCPM ?? obj.ecpm),
      avgCtr: toNum(obj.ctr ?? obj.avg_ctr),
    }
  }

  const daily = dailyArr
    .map((d) => {
      const impressions = toNum(d.impressions ?? d.impr ?? d.shows)
      const revenue = toNum(d.revenue ?? d.earnings ?? d.income)
      return {
        date: String(d.date || d.day || ''),
        revenue,
        impressions,
        clicks: toNum(d.clicks),
        cpm: toNum(d.cpm ?? d.eCPM ?? d.ecpm ?? (impressions ? (revenue / impressions) * 1000 : 0)),
      }
    })
    .filter((d) => d.date)
    .sort((a, b) => a.date.localeCompare(b.date))

  const totalRevenue = daily.reduce((s, d) => s + d.revenue, 0)
  const totalImpressions = daily.reduce((s, d) => s + d.impressions, 0)
  const totalClicks = daily.reduce((s, d) => s + d.clicks, 0)
  const avgCpm = totalImpressions > 0 ? (totalRevenue / totalImpressions) * 1000 : 0
  const avgCtr = totalImpressions > 0 ? (totalClicks / totalImpressions) * 100 : 0

  return { totalRevenue, totalImpressions, totalClicks, avgCpm, avgCtr, daily }
}

function parsePlacements(data: unknown): PlacementInfo {
  const empty: PlacementInfo = { count: 0, items: [] }
  if (!data) return empty
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const o = data as any
  let arr: any[] | null = null
  if (Array.isArray(o)) arr = o
  else if (Array.isArray(o.placements)) arr = o.placements
  else if (Array.isArray(o.data)) arr = o.data
  else if (Array.isArray(o.items)) arr = o.items
  if (!arr) return empty
  const items = arr.map((p) => ({
    id: p.id ?? p.placement_id ?? '',
    title: String(p.title ?? p.name ?? `Placement ${p.id ?? '?'}`),
    domainId: p.domain_id ?? p.domainId,
  }))
  return { count: items.length, items }
}

function parseDomains(data: unknown): DomainInfo {
  const empty: DomainInfo = { count: 0, items: [] }
  if (!data) return empty
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const o = data as any
  let arr: any[] | null = null
  if (Array.isArray(o)) arr = o
  else if (Array.isArray(o.domains)) arr = o.domains
  else if (Array.isArray(o.data)) arr = o.data
  else if (Array.isArray(o.items)) arr = o.items
  if (!arr) return empty
  const items = arr.map((d) => ({
    id: d.id ?? d.domain_id ?? '',
    title: String(d.title ?? d.name ?? d.domain ?? `Domain ${d.id ?? '?'}`),
  }))
  return { count: items.length, items }
}

// ── Component ──────────────────────────────────────────────────────────────

export function AdsterraDashboard() {
  const [summary, setSummary] = useState<AdsterraSummary | null>(null)
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchData = useCallback(async (showSpinner = false) => {
    if (showSpinner) setRefreshing(true)
    try {
      const res = await fetch('/api/adsterra/summary', { credentials: 'same-origin' })
      if (res.status === 401) {
        setError('Authentication required — please log in as admin.')
        setSummary(null)
        return
      }
      const json = (await res.json()) as AdsterraSummary
      setSummary(json)
      setError(json.error || null)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch Adsterra data')
      setSummary(null)
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }, [])

  useEffect(() => {
    fetchData()
  }, [fetchData])

  if (loading) {
    return (
      <div className="rounded-2xl border border-border bg-card p-6 flex items-center justify-center min-h-[200px]">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    )
  }

  // Not configured — show setup hint.
  if (summary && !summary.configured) {
    return (
      <div className="rounded-2xl border border-dashed border-border bg-card p-6 space-y-3">
        <div className="flex items-center gap-2">
          <KeyRound className="h-4 w-4 text-primary" />
          <h3 className="text-sm font-semibold">Adsterra Revenue</h3>
        </div>
        <p className="text-xs text-muted-foreground">
          Connect your Adsterra account to view revenue, impressions, clicks, CPM, and CTR here.
        </p>
        <p className="text-[10px] text-muted-foreground">
          Go to <span className="font-medium">Admin → Settings → Adsterra Revenue API</span> and paste your Publisher API token. Get it from your Adsterra dashboard → <span className="font-mono">Account Settings → API</span>.
        </p>
        <a
          href="https://adsterra.com/blog/how-to-use-adsterra-publishers-api/"
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
        >
          How to get an API token <ExternalLink className="h-3 w-3" />
        </a>
      </div>
    )
  }

  const stats = summary?.stats?.ok && summary.stats.data ? parseStats(summary.stats.data) : null
  const domains = summary?.domains?.ok && summary.domains.data ? parseDomains(summary.domains.data) : null
  const placements = summary?.placements?.ok && summary.placements.data ? parsePlacements(summary.placements.data) : null

  const statsError = summary?.stats && !summary.stats.ok ? summary.stats.error : null
  const statsErrorKind = summary?.stats && !summary.stats.ok ? summary.stats.kind : null
  const domainsError = summary?.domains && !summary.domains.ok ? summary.domains.error : null
  const placementsError = summary?.placements && !summary.placements.ok ? summary.placements.error : null

  const isTokenError = statsErrorKind === 'token-invalid' || statsErrorKind === 'token-missing'
  const hasAnyError = !!error || !!statsError || (domainsError && placementsError && !stats)
  const hasAnyData = !!stats || !!domains || !!placements

  return (
    <div className="rounded-2xl border border-border bg-card overflow-hidden">
      {/* Header */}
      <div className="px-5 py-4 border-b border-border flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500/20 to-emerald-500/10 flex items-center justify-center">
            <DollarSign className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div>
            <h3 className="text-sm font-semibold flex items-center gap-2">
              Adsterra Revenue
              <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-secondary text-muted-foreground font-normal">30 days</span>
            </h3>
            <p className="text-[10px] text-muted-foreground">
              {summary?.fetchedAt ? `Updated ${new Date(summary.fetchedAt).toLocaleString()}` : 'Live from Adsterra API'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <a
            href="https://adsterra.com/dashboard/balance"
            target="_blank"
            rel="noreferrer"
            className="hidden sm:inline-flex items-center gap-1 text-[10px] text-muted-foreground hover:text-primary"
            title="Open Adsterra dashboard"
          >
            <Wallet className="h-3 w-3" /> Balance on Adsterra <ExternalLink className="h-3 w-3" />
          </a>
          <Button
            variant="outline"
            size="sm"
            onClick={() => fetchData(true)}
            disabled={refreshing}
            className="gap-1.5 text-xs h-7"
          >
            <RefreshCw className={`h-3 w-3 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      <div className="p-5 space-y-5">
        {/* Token-invalid error — show a prominent, actionable card */}
        {isTokenError && (
          <div className="rounded-xl border border-amber-500/40 bg-amber-500/5 p-4 text-xs text-amber-700 dark:text-amber-400 flex items-start gap-3">
            <KeyRound className="h-5 w-5 shrink-0 mt-0.5" />
            <div className="space-y-1.5">
              <p className="font-semibold text-sm">Adsterra API token is invalid</p>
              <p className="opacity-90">{statsError}</p>
              <p className="opacity-75">
                The Publisher API token is a 32-character hex string. Make sure you copied it from
                <span className="font-mono"> Adsterra → Account Settings → API</span> (not your ad code snippet).
              </p>
            </div>
          </div>
        )}

        {/* Other errors (only show if no data to display) */}
        {hasAnyError && !hasAnyData && !isTokenError && (
          <div className="rounded-xl border border-red-500/30 bg-red-500/5 p-4 text-xs text-red-600 dark:text-red-400 flex items-start gap-2">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-medium">Couldn&apos;t fetch Adsterra data</p>
              <p className="opacity-90">{error || statsError || domainsError || placementsError}</p>
              <p className="opacity-75 mt-2">If this persists, verify the API token in Settings → Adsterra Revenue API.</p>
            </div>
          </div>
        )}

        {/* Revenue + performance stats — combined 4-card grid */}
        {stats && (
          <>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <StatCard
                icon={<DollarSign className="h-4 w-4" />}
                label="Revenue (30d)"
                value={fmtMoney(stats.totalRevenue)}
                accent="emerald"
                highlight
              />
              <StatCard
                icon={<EyeIcon className="h-4 w-4" />}
                label="Impressions"
                value={fmtNum(stats.totalImpressions)}
                accent="slate"
              />
              <StatCard
                icon={<MousePointerClick className="h-4 w-4" />}
                label="Clicks"
                value={fmtNum(stats.totalClicks)}
                accent="slate"
              />
              <StatCard
                icon={<Percent className="h-4 w-4" />}
                label="Avg CTR"
                value={`${stats.avgCtr.toFixed(2)}%`}
                accent="slate"
              />
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <StatCard
                icon={<TrendingUp className="h-4 w-4" />}
                label="Avg CPM"
                value={fmtMoney(stats.avgCpm)}
                accent="emerald"
              />
              <StatCard
                icon={<Globe className="h-4 w-4" />}
                label="Domains"
                value={domains ? fmtNum(domains.count) : '—'}
                accent="slate"
                hint={domains && domains.count > 0 ? domains.items.slice(0, 3).map((d) => d.title).join(', ') : undefined}
              />
              <StatCard
                icon={<LayoutGrid className="h-4 w-4" />}
                label="Ad Units"
                value={placements ? fmtNum(placements.count) : '—'}
                accent="slate"
                hint={placements && placements.count > 0 ? placements.items.slice(0, 3).map((p) => p.title).join(', ') : undefined}
              />
            </div>
          </>
        )}

        {/* Revenue chart */}
        {stats && stats.daily.length > 1 && (
          <div className="rounded-xl border border-border p-4">
            <h4 className="text-xs font-semibold mb-3 text-muted-foreground">Daily Revenue (30 days)</h4>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={stats.daily} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
                <defs>
                  <linearGradient id="adsterraRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} vertical={false} />
                <XAxis
                  dataKey="date"
                  tickFormatter={fmtDate}
                  tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
                  axisLine={false}
                  tickLine={false}
                  minTickGap={25}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
                  axisLine={false}
                  tickLine={false}
                  width={45}
                  tickFormatter={(v) => `$${v}`}
                />
                <Tooltip
                  content={({ active, payload, label }) => {
                    if (!active || !payload || payload.length === 0) return null
                    const p = payload[0].payload as { revenue: number; impressions: number; clicks: number }
                    return (
                      <div className="rounded-lg border border-border bg-popover px-3 py-2 shadow-xl text-[11px] space-y-1">
                        <p className="font-medium">{fmtDate(String(label))}</p>
                        <p className="text-emerald-600 dark:text-emerald-400">Revenue: ${p.revenue.toFixed(2)}</p>
                        <p className="text-muted-foreground">Impressions: {fmtNum(p.impressions)}</p>
                        <p className="text-muted-foreground">Clicks: {fmtNum(p.clicks)}</p>
                      </div>
                    )
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  stroke="#10b981"
                  strokeWidth={2}
                  fill="url(#adsterraRev)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Partial errors (when stats worked but domains/placements failed, or vice versa) */}
        {(domainsError || placementsError) && hasAnyData && !isTokenError && (
          <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-3 text-[11px] text-amber-700 dark:text-amber-400 flex items-start gap-2">
            <AlertCircle className="h-3.5 w-3.5 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              {domainsError && <p>Domains endpoint: {domainsError}</p>}
              {placementsError && <p>Placements endpoint: {placementsError}</p>}
            </div>
          </div>
        )}

        {/* Empty state */}
        {!hasAnyData && !hasAnyError && (
          <div className="text-center py-6 text-xs text-muted-foreground space-y-1">
            <p>No Adsterra data available yet.</p>
            <p className="opacity-75">New accounts may take 24-48h for the first stats to appear.</p>
          </div>
        )}
      </div>
    </div>
  )
}

// ── Stat card subcomponent ────────────────────────────────────────────────

function StatCard({
  icon,
  label,
  value,
  accent,
  highlight,
  hint,
}: {
  icon: React.ReactNode
  label: string
  value: string
  accent: 'emerald' | 'amber' | 'blue' | 'slate'
  highlight?: boolean
  hint?: string
}) {
  const accents: Record<string, string> = {
    emerald: 'from-emerald-500/20 to-emerald-500/5 text-emerald-600 dark:text-emerald-400',
    amber: 'from-amber-500/20 to-amber-500/5 text-amber-600 dark:text-amber-400',
    blue: 'from-sky-500/20 to-sky-500/5 text-sky-600 dark:text-sky-400',
    slate: 'from-slate-500/20 to-slate-500/5 text-slate-600 dark:text-slate-400',
  }
  return (
    <div
      className={`relative overflow-hidden rounded-xl border p-3 ${
        highlight
          ? 'border-emerald-500/30 bg-gradient-to-br from-emerald-500/10 to-transparent'
          : 'border-border bg-secondary/30'
      }`}
    >
      <div className="flex items-center gap-1.5 mb-1">
        <div className={`w-6 h-6 rounded-md bg-gradient-to-br ${accents[accent]} flex items-center justify-center shrink-0`}>
          {icon}
        </div>
        <span className="text-[10px] text-muted-foreground uppercase tracking-wider truncate">{label}</span>
      </div>
      <p className={`text-lg font-bold tabular-nums ${highlight ? 'text-emerald-600 dark:text-emerald-400' : ''}`}>
        {value}
      </p>
      {hint && (
        <p className="text-[9px] text-muted-foreground mt-0.5 truncate" title={hint}>{hint}</p>
      )}
    </div>
  )
}
