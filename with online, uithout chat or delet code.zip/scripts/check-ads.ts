import { db } from '../src/lib/db'

async function main() {
  const settings = await db.appSetting.findFirst()
  if (!settings) {
    console.log('No settings found')
    return
  }
  console.log('adsEnabled:', settings.adsEnabled)
  console.log('homeAdsEnabled:', settings.homeAdsEnabled)
  console.log('videoAdsEnabled:', settings.videoAdsEnabled)
  console.log('bannerAdScript (first 500 chars):', settings.bannerAdScript?.substring(0, 500) || '(empty)')
  console.log('---')
  console.log('socialBarAdScript (first 500 chars):', settings.socialBarAdScript?.substring(0, 500) || '(empty)')
  console.log('---')
  console.log('customAdScripts:')
  try {
    const all = JSON.parse(settings.customAdScripts || '[]')
    console.log('Total:', all.length)
    for (const ad of all) {
      console.log(`  - id: ${ad.id}, name: ${ad.name}, position: ${ad.position}, enabled: ${ad.enabled}`)
      console.log(`    script (first 400): ${(ad.script || '').substring(0, 400)}`)
    }
  } catch (e) {
    console.log('Parse error:', e)
  }
}

main().then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1) })
